<?php /** * Created by SSDMAThemes. * User: Dmitry Nizovsky * Date: 21.01.15 * Time: 17:59 */ ?>
<nav class="breadcrumb b-breadcrumb"><?php ssdma_breadcrumbs(); ?></nav>