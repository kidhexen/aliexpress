$(document).ready(function() {
    $('.mobile_menu').click(
        $('.menu-menu_header-1').toggle()
    );
});