<?php
/**
 * Created by AL1.
 * User: Dmitry Nizovsky
 * Date: 16.02.15
 * Time: 18:02
 */

include get_template_directory() . '/config/init.php';