<?php get_header(); ?>
    <div class="container base-mar-t-20">
	    <div class="grid-277 clearfix"><?php get_sidebar(); ?></div>
	    <div class="grid-900 grid-m-23 clearfix">
            <?php if ( get_header_image() ) : ?>
			    <div class="hidden-xs">
			        <div class="fotorama">

					    <span class="fotorama">
						    <div class="b-header-img">
							    <img src="<?php header_image(); ?>">
						        <?php if ( display_header_text() ): ?>
						<div class="b-header-img__caption"><?php echo get_option( 'ssdma_htext_line' ); ?><br/>
							<a class="btn btn-cred" href="<?php echo esc_url( home_url( '/products' ) ); ?>">
								<?php
								$Catalog = get_option('ssdma_catalogue');

								if ( $Catalog && $Catalog != '' ):
									echo get_option( "ssdma_catalogue" );
								else:
									echo _e( 'Go to Catalogue', 'ssdma' );
								endif;
								?></a>
						</div><?php endif; ?>
						</div>
					</span>

				<?php if ( get_option( 'ssdma_slider_image2' ) ): ?>
							<span class="fotorama">
								<div class="b-header-img">
									<img src="<?php echo get_option( 'ssdma_slider_image2' ); ?>"/>
									<div class="b-header-img__caption">
										<?php echo get_option( 'ssdma_htext_line2' ); ?><br/>
										<a class="btn btn-cred slider_btn2" href="<?php echo esc_url( home_url( '/products' ) ); ?>">
											<?php

											$Catalog2 = get_option('ssdma_catalogue2');

											if ( $Catalog2 && $Catalog2 != '' ):
												echo get_option( "ssdma_catalogue2" );
											else:
												echo _e( 'Go to Catalogue', 'ssdma' );
											endif;
											?></a>
								</div>
								</div></span>
				<?php endif; ?>

				<?php if ( get_option( 'ssdma_slider_image3' ) ): ?>
					<span class="fotorama">
								<div class="b-header-img">
									<img src="<?php echo get_option( 'ssdma_slider_image3' ); ?>"/>
									<div class="b-header-img__caption">
										<?php echo get_option( 'ssdma_htext_line3' ); ?><br/>
										<a class="btn btn-cred slider_btn3" href="<?php echo esc_url( home_url( '/products' ) ); ?>">
											<?php

											$Catalog3 = get_option('ssdma_catalogue3');

											if ( $Catalog3 && $Catalog3 != '' ):
												echo get_option( "ssdma_catalogue3" );
											else:
												echo _e( 'Go to Catalogue', 'ssdma' );
											endif;
											?></a>
									</div>
								</div></span>
				<?php endif; ?><?php endif; ?>
			</div>
			</div>
		<div
			class="b-protection clearfix base-mar-20"><?php get_template_part( 'templates/protection' ); ?></div><?php get_template_part( 'templates/products-special' ); ?><?php get_template_part( 'templates/product-latest' ); ?><?php $ban1 = get_option( 'ssdma_banners_1' );
		if ( $ban1 ): ?>
			<div
				class="clearfix text-center base-mar-b-20"><?php echo $ban1; ?></div><?php endif; ?><?php get_template_part( 'templates/product-cat-1' ); ?><?php $ban2 = get_option( 'ssdma_banners_2' );
		if ( $ban2 ): ?>
			<div
				class="clearfix text-center base-mar-b-20"><?php echo $ban2; ?></div><?php endif; ?><?php get_template_part( 'templates/product-cat-2' ); ?>
	</div>
	<div class="clearfix"></div></div><?php get_template_part( 'templates/footer-before' ); ?>    <?php
$seo_main = get_option( 'ssdma_seo_main' );
echo $seo_main; ?><?php get_footer(); ?>